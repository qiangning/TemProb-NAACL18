1. Introduction

This package contains the data sets used in the following paper:
Q. Do and Y. Chan and D. Roth, Minimally Supervised Event Causality Identification. EMNLP  (2011)

Authors:
Quang Do (quangdo2@illinois.edu)
Yee Seng Chan (chanys@illinois.edu)
Dan Roth (danr@illinois.edu)

2. The data
In each data file, each document content is under <S1>, the sentences are under <S2>, and the tokens and their part-of-speech are under <S3>.
You will also see the key files, which are fairly self-explanatory.
